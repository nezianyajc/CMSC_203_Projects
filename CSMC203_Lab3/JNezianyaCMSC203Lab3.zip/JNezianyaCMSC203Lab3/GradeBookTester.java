import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;


class GradeBookTester {
	private GradeBook myFirstGrade;
	private GradeBook mySecondGrade;


	
	@BeforeEach
	public void setUp() {
		myFirstGrade = new GradeBook(5);
		mySecondGrade = new GradeBook(5);
		
		myFirstGrade.addScore(95.0);
		myFirstGrade.addScore(65.0);

		mySecondGrade.addScore(55.0);
		mySecondGrade.addScore(45.0);
		mySecondGrade.addScore(75.0);
	}

	@AfterEach
	public void tearDown() throws Exception {
		myFirstGrade = null;
		mySecondGrade = null;
	}



	@Test
	public void testSum() {
		assertEquals(160.0, myFirstGrade.sum(),0.1);
		assertEquals(175.0, mySecondGrade.sum(),0.1);
	}

	@Test
	void testMinimum() {
		assertEquals(65.0, myFirstGrade.minimum(), 0.1);
		assertEquals(45.0, mySecondGrade.minimum(), 0.1);
	}

	@Test
	public void testFinalScore() {
		
	}

	@Test
	public void testGetScoreSize() {
	   assertEquals(2,myFirstGrade.getScoreSize(), 0.1);
	   assertEquals(3, mySecondGrade.getScoreSize(), 0.1);

	}

	@Test
	void testToString() {
	}

}
